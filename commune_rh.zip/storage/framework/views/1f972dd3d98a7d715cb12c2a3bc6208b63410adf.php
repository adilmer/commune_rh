<?php $__env->startSection('content'); ?>
<body class="text-center">
<form class="form-signin" method="POST" action="<?php echo e(route('login')); ?>">
       <?php echo csrf_field(); ?>
      <img class="mb-4" src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" width="80" height="120">
      <h1 class="h3 mb-3 font-weight-normal">تسجيل الدخول</h1>
      <label for="inputEmail" class="sr-only">بيانات الدخول</label>
      <input id="email" type="email" placeholder="البريد الالكتروني" class="form-control text-left <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="اسم المستخدم" autofocus>
      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <label for="inputPassword" class="sr-only">الرمز السري</label>
      <input id="password" type="password" class="form-control text-left <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="الرمز السري" name="password" required autocomplete="الرمز السري">
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
       </span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <div class="checkbox mb-3">
        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

      <label class="form-check-label" for="remember">
        <?php echo e(__('حفظ الدخول')); ?>

      </label>
      </div>


      <div class="divlogin">
        <button type="submit" class="btn btn-lg btn-primary btn-block">
            <?php echo e(__('دخول')); ?>

        </button>

        <?php if(Route::has('password.request')): ?>
            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('نسيت كلمة السر ؟')); ?>

            </a>
        <?php endif; ?>
    </div>




      <p class="mt-5 mb-3 text-muted">© 2023 بلدية طانطان</p>
    </form>
</body>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.vide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khadija Elmer\Desktop\commune_rh\resources\views/auth/login.blade.php ENDPATH**/ ?>