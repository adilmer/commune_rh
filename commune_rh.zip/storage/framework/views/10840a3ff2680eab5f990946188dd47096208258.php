
<?php $__env->startSection('content'); ?>
<div class="bg-light p-4 rounded">
    <h2>إضافة صلاحية جديدة</h2>


    <div class="container mt-4">

        <form method="POST" action="<?php echo e(route('permissions.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">إسم الصلاحية</label>
                <input value="<?php echo e(old('name_ar')); ?>"
                    type="text"
                    class="form-control"
                    name="name_ar"
                    placeholder="" required>

                <?php if($errors->has('name_ar')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('name_ar')); ?></span>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">إسم الروت</label>
                <input value="<?php echo e(old('name')); ?>"
                    type="text"
                    class="form-control"
                    name="name"
                    placeholder="" required>

                <?php if($errors->has('name')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="order" class="form-label">الرقم الترتيبي</label>
                <input value="<?php echo e(old('order')); ?>"
                    type="number"
                    class="form-control"
                    name="order"
                    placeholder="">
            </div>

            <button type="submit" class="btn btn-primary">حفظ الصلاحية </button>
            <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-success">عودة</a>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khadija Elmer\Desktop\commune_rh\resources\views/permissions/create.blade.php ENDPATH**/ ?>