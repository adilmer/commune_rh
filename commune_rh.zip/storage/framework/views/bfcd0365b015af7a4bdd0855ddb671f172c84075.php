
<?php $__env->startSection('content'); ?>
<div class="col-lg">
                <div class="card">
                  <div class="card-body">
                    <div class="mb-3 mb-sm-0">
                      <h5 class="card-title fw-semibold">الموظفين في رخصة</h5>
                    </div>
                    <div class="table">
                      <table class="table mb-0 align-middle">
                      <thead class="text-dark fs-4 table-primary">
                      <tr>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">إسم الموظف</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">تاريخ إستئناف العمل</h6>
                        </th>
                        <th class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">ينوب عنه</h6>
                        </th>
                      </tr>
                    </thead>
                        <tbody>
                        <?php $__currentLoopData = $listconge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listconge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border-bottom-0">
                                <h6 class="fw-semibold mb-1"><?php echo e($listconge -> nom_ar); ?></h6>
                            </td>
                            <td class="border-bottom-0">
                              <p class="mb-0 fw-normal"><?php echo e($listconge -> date_prise); ?></p>
                            </td>
                            <td class="border-bottom-0">
                                <p class="mb-0 fw-normal"><?php echo e($listconge -> remplacant); ?></p>
                              </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khadija Elmer\Desktop\commune_rh\resources\views/homepage/listconge.blade.php ENDPATH**/ ?>