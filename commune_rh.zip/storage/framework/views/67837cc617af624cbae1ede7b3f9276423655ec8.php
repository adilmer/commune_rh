<?php $__env->startSection('content'); ?>
<div class="row " style="justify-content: flex-end;">
    <form action="<?php echo e(route('stagiaire.export_word_attestation')); ?>" method="get">

      <div class="col-sm-2 m-3 ">
        <button class="btn btn-primary"> لائحة المتدربين</button>
      </div>
        <div class="row fs-4">
            <input type="hidden" class="form-control" value="<?php echo e($stagiaire->id_stagiaire); ?>" id="id_stagiaire" name="id_stagiaire" placeholder="" value="" required>
          <div class="col-lg-12 d-flex align-items-stretch">
            <div class="card w-100">
              <div class="card-body p-4">
                <h5 class="card-title fw-semibold mb-4">معلومات المتدرب </h5>
                <div class="table-responsive">
                  <table class="table text-nowrap mb-0 align-middle">
                    <tbody>
                      <tr>
                        <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">الإسم الكامل  :</h6>
                        </td>
                        <td class="border-bottom-0">
                          <p class="mb-0 fw-normal"><?php echo e($stagiaire->nom_stagiaire_ar); ?> | <?php echo e($stagiaire->nom_stagiaire_fr); ?></p>
                        </td>
                      </tr>
                      <tr>
                        <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">تاريخ بداية التدريب :</h6>
                        </td>
                        <td class="border-bottom-0">
                          <p class="mb-0 fw-normal">  <?php echo e($stagiaire->date_debut_stage->format('Y-m-d')); ?> </p>
                        </td>
                      </tr>
                      <tr>
                        <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">تاريخ نهاية التدريب :</h6>
                        </td>
                        <td class="border-bottom-0">
                          <p class="mb-0 fw-normal">  <?php echo e($stagiaire->date_fin_stage->format('Y-m-d')); ?> </p>
                        </td>
                      </tr>
                      <tr>
                        <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">  مؤسسة المتدرب :</h6>
                        </td>
                        <td class="border-bottom-0">
                          <p class="mb-0 fw-normal">  <?php echo e($stagiaire->direction_stagiaire); ?> </p>
                        </td>
                      </tr>
                      <tr>
                        <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">  شعبة المتدرب :</h6>
                        </td>
                        <td class="border-bottom-0">
                          <p class="mb-0 fw-normal">  <?php echo e($stagiaire->filiere_stagiaire); ?> </p>
                        </td>
                      </tr>
                      <tr>
                        <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-0">الوثائق  :</h6>
                        </td>
                          <td class="border-bottom-0">
                            <a href="<?php echo e(asset('documents_stagiaires/'.$stagiaire->path_stagiaire)); ?>"  class="btn btn-danger"><i class="ti ti-file-text"></i> طلب المتدرب </a>
                            <button name="type" value="acceptationstage" class="btn btn-danger"><i class="ti ti-file-text"></i> الموافقة</button><br><br>
                            <button class="btn btn-danger"><i class="ti ti-file-text"></i>  ورقة الحضور</button>
                            <button name="type" value="attestationstage" class="btn btn-danger"><i class="ti ti-file-text"></i> شهادة التدريب  </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
    </form>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khadija Elmer\Desktop\commune_rh\resources\views/pages/stagiaires/details.blade.php ENDPATH**/ ?>